const db = require('../config/db');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

async function getAllMembers(req, res) {
  try {
    const { trainerUserId } = req.query;
    let staffId = null;

    if (trainerUserId) {
      const [userRows] = await db.query(
        'SELECT id, email, username FROM users WHERE id = ?',
        [trainerUserId]
      );
      if (userRows.length > 0) {
        const u = userRows[0];
        const [staffRows] = await db.query(
          'SELECT id FROM staff WHERE email = ? OR username = ? LIMIT 1',
          [u.email, u.username]
        );
        if (staffRows.length > 0) {
          staffId = staffRows[0].id;
        } else {
          // If trainerUserId was provided but no staff matches, return empty to avoid leak
          return res.json([]);
        }
      } else {
        return res.json([]);
      }
    }

    let sql;
    let params = [];

    if (staffId) {
      sql = `
        SELECT 
          gm.id, 
          gm.member_id, 
          gm.fingerprint_id,
          gm.name, 
          gm.phone, 
          gm.email, 
          gm.gender,
          gm.height,
          gm.weight,
          gm.bmi,
          gm.plan,
          gm.status,
          gm.address,
          gm.dob,
          gm.age,
          gm.employer,
          gm.occupation,
          gm.emergency_contact_name,
          gm.emergency_contact_relationship,
          gm.emergency_contact_address,
          gm.emergency_contact_phone_home,
          gm.emergency_contact_phone_work,
          gm.fitness_goal,
          gm.blood_group,
          gm.pt_form_completed,
          u.id AS u_id, 
          COALESCE(gm.user_id, u.user_id) AS u_uuid,
          u.email AS user_email, 
          u.role,
          (SELECT COUNT(*) FROM workout_programs wp WHERE wp.member_id = gm.id) AS workout_count,
          (SELECT COUNT(*) FROM diet_plans dp WHERE dp.member_id = gm.id) AS diet_count,
          gm.join_date,
          gm.expiry_date,
          gm.created_at,
          m_pay.paymentMode,
          m_pay.price,
          m_pay.pricePaid,
          m_pay.secondPaymentPaid,
          'members' as source
        FROM gym_members gm
        INNER JOIN users u ON (u.email = gm.email AND gm.email IS NOT NULL AND gm.email != '') 
                          OR (u.mobile = gm.phone AND gm.phone IS NOT NULL AND gm.phone != '')
        INNER JOIN trainer_assignments ta ON ta.user_id = u.id AND ta.trainer_id = ?
        LEFT JOIN (
          SELECT m.userId, m.paymentMode, m.price, m.pricePaid, m.secondPaymentPaid
          FROM memberships m
          JOIN (
            SELECT userId, MAX(id) AS max_id
            FROM memberships
            GROUP BY userId
          ) mm ON m.userId = mm.userId AND m.id = mm.max_id
        ) m_pay ON m_pay.userId = u.id
        
        UNION ALL
        
        SELECT 
          NULL as id, 
          NULL as member_id, 
          NULL as fingerprint_id,
          u.username as name, 
          u.mobile as phone, 
          u.email, 
          NULL as gender,
          NULL as height,
          NULL as weight,
          NULL as bmi,
          NULL as plan,
          'active' as status,
          NULL as address,
          NULL as dob,
          NULL as age,
          NULL as employer,
          NULL as occupation,
          NULL as emergency_contact_name,
          NULL as emergency_contact_relationship,
          NULL as emergency_contact_address,
          NULL as emergency_contact_phone_home,
          NULL as emergency_contact_phone_work,
          NULL as fitness_goal,
          NULL as blood_group,
          0 as pt_form_completed,
          u.id AS u_id, 
          COALESCE(NULL, u.user_id) AS u_uuid,
          u.email AS user_email, 
          u.role,
          0 AS workout_count,
          0 AS diet_count,
          NULL as join_date,
          NULL as expiry_date,
          u.created_at,
          NULL as paymentMode,
          NULL as price,
          NULL as pricePaid,
          NULL as secondPaymentPaid,
          'users' as source
        FROM users u
        INNER JOIN trainer_assignments ta ON ta.user_id = u.id AND ta.trainer_id = ?
        WHERE u.role = 'user' AND NOT EXISTS (
          SELECT 1 FROM gym_members gm2 
          WHERE (gm2.email = u.email AND u.email IS NOT NULL AND u.email != '') 
             OR (gm2.phone = u.mobile AND u.mobile IS NOT NULL AND u.mobile != '')
        )
        
        ORDER BY created_at DESC
      `;
      params = [staffId, staffId];
    } else {
      sql = `
        SELECT 
          gm.id, 
          gm.member_id, 
          gm.fingerprint_id,
          gm.name, 
          gm.phone, 
          gm.email, 
          gm.gender,
          gm.height,
          gm.weight,
          gm.bmi,
          gm.plan,
          gm.status,
          gm.address,
          gm.dob,
          gm.age,
          gm.employer,
          gm.occupation,
          gm.emergency_contact_name,
          gm.emergency_contact_relationship,
          gm.emergency_contact_address,
          gm.emergency_contact_phone_home,
          gm.emergency_contact_phone_work,
          gm.fitness_goal,
          gm.blood_group,
          gm.pt_form_completed,
          u.id AS u_id, 
          COALESCE(gm.user_id, u.user_id) AS u_uuid,
          u.email AS user_email, 
          u.role,
          (SELECT COUNT(*) FROM workout_programs wp WHERE wp.member_id = gm.id) AS workout_count,
          (SELECT COUNT(*) FROM diet_plans dp WHERE dp.member_id = gm.id) AS diet_count,
          gm.join_date,
          gm.expiry_date,
          gm.created_at,
          m_pay.paymentMode,
          m_pay.price,
          m_pay.pricePaid,
          m_pay.secondPaymentPaid,
          'members' as source
        FROM gym_members gm
        LEFT JOIN users u ON (u.email = gm.email AND gm.email IS NOT NULL AND gm.email != '') 
                          OR (u.mobile = gm.phone AND gm.phone IS NOT NULL AND gm.phone != '')
        LEFT JOIN (
          SELECT m.userId, m.paymentMode, m.price, m.pricePaid, m.secondPaymentPaid
          FROM memberships m
          JOIN (
            SELECT userId, MAX(id) AS max_id
            FROM memberships
            GROUP BY userId
          ) mm ON m.userId = mm.userId AND m.id = mm.max_id
        ) m_pay ON m_pay.userId = u.id
        
        UNION ALL
        
        SELECT 
          NULL as id, 
          NULL as member_id, 
          NULL as fingerprint_id,
          u.username as name, 
          u.mobile as phone, 
          u.email, 
          NULL as gender,
          NULL as height,
          NULL as weight,
          NULL as bmi,
          NULL as plan,
          'active' as status,
          NULL as address,
          NULL as dob,
          NULL as age,
          NULL as employer,
          NULL as occupation,
          NULL as emergency_contact_name,
          NULL as emergency_contact_relationship,
          NULL as emergency_contact_address,
          NULL as emergency_contact_phone_home,
          NULL as emergency_contact_phone_work,
          NULL as fitness_goal,
          NULL as blood_group,
          0 as pt_form_completed,
          u.id AS u_id, 
          COALESCE(NULL, u.user_id) AS u_uuid,
          u.email AS user_email, 
          u.role,
          0 AS workout_count,
          0 AS diet_count,
          NULL as join_date,
          NULL as expiry_date,
          u.created_at,
          NULL as paymentMode,
          NULL as price,
          NULL as pricePaid,
          NULL as secondPaymentPaid,
          'users' as source
        FROM users u
        WHERE u.role = 'user' AND NOT EXISTS (
          SELECT 1 FROM gym_members gm2 
          WHERE (gm2.email = u.email AND u.email IS NOT NULL AND u.email != '') 
             OR (gm2.phone = u.mobile AND u.mobile IS NOT NULL AND u.mobile != '')
        )
        
        ORDER BY created_at DESC
      `;
    }

    let rows;
    try {
      [rows] = await db.query(sql, params);
      res.json(rows);
      return;
    } catch (err) {
      console.warn('getAllMembers primary query failed, falling back to gym-members only query', err.message || err);
    }

    // Fallback to simpler gym-members only query
    let fallbackSql;
    let fallbackParams = [];

    if (staffId) {
      fallbackSql = `
        SELECT 
          gm.id,
          gm.member_id,
          COALESCE(gm.fingerprint_id, NULL) AS fingerprint_id,
          gm.name,
          gm.phone,
          gm.email,
          gm.gender,
          gm.height,
          gm.weight,
          gm.bmi,
          gm.plan,
          gm.status,
          gm.address,
          COALESCE(gm.dob, NULL) AS dob,
          COALESCE(gm.age, NULL) AS age,
          COALESCE(gm.employer, NULL) AS employer,
          COALESCE(gm.occupation, NULL) AS occupation,
          COALESCE(gm.emergency_contact_name, NULL) AS emergency_contact_name,
          COALESCE(gm.emergency_contact_relationship, NULL) AS emergency_contact_relationship,
          COALESCE(gm.emergency_contact_address, NULL) AS emergency_contact_address,
          COALESCE(gm.emergency_contact_phone_home, NULL) AS emergency_contact_phone_home,
          COALESCE(gm.emergency_contact_phone_work, NULL) AS emergency_contact_phone_work,
          COALESCE(gm.fitness_goal, NULL) AS fitness_goal,
          COALESCE(gm.blood_group, NULL) AS blood_group,
          COALESCE(gm.pt_form_completed, 0) AS pt_form_completed,
          u.id AS u_id,
          COALESCE(gm.user_id, u.user_id) AS u_uuid,
          u.email AS user_email,
          u.role,
          (SELECT COUNT(*) FROM workout_programs wp WHERE wp.member_id = gm.id) AS workout_count,
          (SELECT COUNT(*) FROM diet_plans dp WHERE dp.member_id = gm.id) AS diet_count,
          gm.join_date,
          gm.expiry_date,
          gm.created_at,
          NULL AS paymentMode,
          NULL AS price,
          NULL AS pricePaid,
          NULL AS secondPaymentPaid,
          'members' AS source
        FROM gym_members gm
        INNER JOIN users u ON (u.email = gm.email AND gm.email IS NOT NULL AND gm.email != '')
                          OR (u.mobile = gm.phone AND gm.phone IS NOT NULL AND gm.phone != '')
        INNER JOIN trainer_assignments ta ON ta.user_id = u.id AND ta.trainer_id = ?
        ORDER BY gm.created_at DESC
      `;
      fallbackParams = [staffId];
    } else {
      fallbackSql = `
        SELECT 
          gm.id,
          gm.member_id,
          COALESCE(gm.fingerprint_id, NULL) AS fingerprint_id,
          gm.name,
          gm.phone,
          gm.email,
          gm.gender,
          gm.height,
          gm.weight,
          gm.bmi,
          gm.plan,
          gm.status,
          gm.address,
          COALESCE(gm.dob, NULL) AS dob,
          COALESCE(gm.age, NULL) AS age,
          COALESCE(gm.employer, NULL) AS employer,
          COALESCE(gm.occupation, NULL) AS occupation,
          COALESCE(gm.emergency_contact_name, NULL) AS emergency_contact_name,
          COALESCE(gm.emergency_contact_relationship, NULL) AS emergency_contact_relationship,
          COALESCE(gm.emergency_contact_address, NULL) AS emergency_contact_address,
          COALESCE(gm.emergency_contact_phone_home, NULL) AS emergency_contact_phone_home,
          COALESCE(gm.emergency_contact_phone_work, NULL) AS emergency_contact_phone_work,
          COALESCE(gm.fitness_goal, NULL) AS fitness_goal,
          COALESCE(gm.blood_group, NULL) AS blood_group,
          COALESCE(gm.pt_form_completed, 0) AS pt_form_completed,
          u.id AS u_id,
          COALESCE(gm.user_id, u.user_id) AS u_uuid,
          u.email AS user_email,
          u.role,
          (SELECT COUNT(*) FROM workout_programs wp WHERE wp.member_id = gm.id) AS workout_count,
          (SELECT COUNT(*) FROM diet_plans dp WHERE dp.member_id = gm.id) AS diet_count,
          gm.join_date,
          gm.expiry_date,
          gm.created_at,
          NULL AS paymentMode,
          NULL AS price,
          NULL AS pricePaid,
          NULL AS secondPaymentPaid,
          'members' AS source
        FROM gym_members gm
        LEFT JOIN users u ON (u.email = gm.email AND gm.email IS NOT NULL AND gm.email != '')
                          OR (u.mobile = gm.phone AND gm.phone IS NOT NULL AND gm.phone != '')
        ORDER BY gm.created_at DESC
      `;
    }
    [rows] = await db.query(fallbackSql, fallbackParams);
    res.json(rows);
  } catch (err) {
    console.error('getAllMembers error', err);
    res.status(500).json({ error: 'Query failed' });
  }
}

async function getMemberById(req, res) {
  try {
    const { id } = req.params;
    const idNum = parseInt(id, 10);
    const isNum = !isNaN(idNum);

    let sql;
    let params;
    if (isNum) {
      sql = `
        SELECT gm.*,
               u.id AS u_id,
               COALESCE(gm.user_id, u.user_id) AS u_uuid,
               u.email AS user_email,
               (SELECT COUNT(*) FROM workout_programs wp WHERE wp.member_id = gm.id) AS workout_count,
               (SELECT COUNT(*) FROM diet_plans dp WHERE dp.member_id = gm.id) AS diet_count
        FROM gym_members gm
        LEFT JOIN users u ON (u.email = gm.email AND gm.email IS NOT NULL AND gm.email != '') OR (u.mobile = gm.phone AND gm.phone IS NOT NULL AND gm.phone != '')
        WHERE gm.id = ?
      `;
      params = [idNum];
    } else {
      sql = `
        SELECT gm.*,
               u.id AS u_id,
               COALESCE(gm.user_id, u.user_id) AS u_uuid,
               u.email AS user_email,
               (SELECT COUNT(*) FROM workout_programs wp WHERE wp.member_id = gm.id) AS workout_count,
               (SELECT COUNT(*) FROM diet_plans dp WHERE dp.member_id = gm.id) AS diet_count
        FROM gym_members gm
        LEFT JOIN users u ON (u.email = gm.email AND gm.email IS NOT NULL AND gm.email != '') OR (u.mobile = gm.phone AND gm.phone IS NOT NULL AND gm.phone != '')
        WHERE gm.member_id = ?
      `;
      params = [id];
    }

    const [rows] = await db.query(sql, params);
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Member not found' });
    }
    res.json(rows[0]);
  } catch (err) {
    console.error('getMemberById error', err);
    res.status(500).json({ error: 'Query failed' });
  }
}

async function getMemberByUserId(req, res) {
  try {
    const { user_id } = req.params;
    const [memberRows] = await db.query(
      `SELECT gm.*, u.id AS u_id, u.user_id AS u_uuid, u.email AS user_email
       FROM gym_members gm
       JOIN users u ON (u.email = gm.email AND gm.email IS NOT NULL AND gm.email != '')
                    OR (u.mobile = gm.phone AND gm.phone IS NOT NULL AND gm.phone != '')
       WHERE u.id = ?
       LIMIT 1`,
      [user_id]
    );

    if (memberRows.length > 0) {
      return res.json({ ...memberRows[0], source: 'member' });
    }

    const [userRows] = await db.query(
      `SELECT id AS u_id, user_id AS u_uuid, username AS name, email, mobile AS phone, role
       FROM users
       WHERE id = ?`,
      [user_id]
    );

    if (userRows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    return res.json({ ...userRows[0], source: 'user' });
  } catch (err) {
    console.error('getMemberByUserId error', err);
    res.status(500).json({ error: 'Query failed' });
  }
}

async function createMemberRecord(connection, payload) {
  const {
    name, phone, email, gender, height, weight, bmi,
    plan, duration, joinDate, expiryDate, status,
    photo, notes, address,
    username, password,
    dob, age, employer, occupation,
    emergency_contact_name, emergency_contact_relationship, emergency_contact_address,
    emergency_contact_phone_home, emergency_contact_phone_work,
    fitness_goal, blood_group, pt_form_completed,
    fingerprintId
  } = payload;

  const resolvedName = name || "Unknown";
  const resolvedPhone = phone || "";

  if (resolvedPhone || email) {
    const [existingMember] = await connection.query(
      "SELECT id FROM gym_members WHERE (phone != '' AND phone = ?) OR (email IS NOT NULL AND email != '' AND email = ?)",
      [resolvedPhone, email]
    );

    if (existingMember.length > 0) {
      throw new Error("A member with this phone or email already exists in members directory");
    }
  }

  const [existingUser] = await connection.query(
    "SELECT id, user_id FROM users WHERE (mobile = ? AND mobile != '') OR (email = ? AND email IS NOT NULL AND email != '')",
    [resolvedPhone, email]
  );

  let userId_uuid = existingUser.length > 0 ? existingUser[0].user_id : uuidv4();

  const numHeight = height != null && !isNaN(height) ? Number(height) : null;
  const numWeight = weight != null && !isNaN(weight) ? Number(weight) : null;
  const numBmi = bmi != null && !isNaN(bmi) ? Number(bmi) : null;
  const numDuration = duration != null && !isNaN(duration) ? Number(duration) : null;

  const [maxResult] = await connection.query(
    "SELECT MAX(CAST(member_id AS UNSIGNED)) as maxnum FROM gym_members"
  );

  let nextNumber = (maxResult[0].maxnum || 0) + 1;
  let memberId = String(nextNumber);

  let inserted = false;
  let result;
  for (let attempt = 0; attempt < 2 && !inserted; attempt++) {
    try {
      [result] = await connection.query(
        `INSERT INTO gym_members
      (user_id, member_id, name, phone, email, gender, height, weight, bmi, plan, duration,
       join_date, expiry_date, status, photo, notes, address,
       dob, age, employer, occupation,
       emergency_contact_name, emergency_contact_relationship, emergency_contact_address,
       emergency_contact_phone_home, emergency_contact_phone_work,
       fitness_goal, blood_group, pt_form_completed, fingerprint_id)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        [
          userId_uuid, memberId, resolvedName, resolvedPhone, email, gender, numHeight, numWeight, numBmi,
          plan, numDuration, joinDate, expiryDate, status, photo, notes, address,
          dob || null, age || null, employer || null, occupation || null,
          emergency_contact_name || null, emergency_contact_relationship || null, emergency_contact_address || null,
          emergency_contact_phone_home || null, emergency_contact_phone_work || null,
          fitness_goal || null, blood_group || null,
          pt_form_completed ? 1 : 0,
          fingerprintId || null
        ]
      );
      inserted = true;
    } catch (err) {
      if (err.code === 'ER_DUP_ENTRY' && err.sqlMessage.includes('member_id')) {
        nextNumber += 1;
        memberId = String(nextNumber);
      } else {
        throw err;
      }
    }
  }

  if (!inserted) {
    throw new Error('Failed to generate unique member_id');
  }

  if (email || resolvedPhone) {
    try {
      const pwd = password || resolvedPhone || 'Gym123';
      const hashed = await bcrypt.hash(pwd, 10);

      if (existingUser.length > 0) {
        await connection.query(
          `UPDATE users SET password_hash = ?, username = ? WHERE id = ?`,
          [hashed, username || null, existingUser[0].id]
        );
      } else {
        await connection.query(
          `INSERT INTO users (user_id, email, password_hash, role, username, mobile)
               VALUES (?, ?, ?, ?, ?, ?)`,
          [userId_uuid, email || null, hashed, 'user', username || null, resolvedPhone || null]
        );
      }
    } catch (userErr) {
      if (userErr.code === 'ER_DUP_ENTRY') {
        console.warn('createMember: user already exists (duplicate entry), skipping user insert');
      } else {
        throw userErr;
      }
    }
  }

  const [fetched] = await connection.query(
    `
      SELECT gm.*,
             u.id AS u_id,
             u.user_id AS u_uuid,
             u.email AS user_email,
             0 AS workout_count,
             0 AS diet_count
      FROM gym_members gm
      LEFT JOIN users u ON (u.email = gm.email AND gm.email IS NOT NULL AND gm.email != '') OR (u.mobile = gm.phone AND gm.phone IS NOT NULL AND gm.phone != '')
      WHERE gm.member_id = ?
    `,
    [memberId]
  );

  return fetched[0] || {
    id: result.insertId,
    member_id: memberId,
    name: resolvedName,
    phone: resolvedPhone,
    email,
    gender,
    height: numHeight,
    weight: numWeight,
    bmi: numBmi,
    plan,
    duration: numDuration,
    join_date: joinDate,
    expiry_date: expiryDate,
    status,
    photo,
    notes,
    address
  };
}

async function createMember(req, res) {
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();
    const member = await createMemberRecord(connection, req.body);
    await connection.commit();
    res.json(member);
  } catch (err) {
    await connection.rollback();
    console.error('createMember error:', err.message || err);
    if (err.message && err.message.includes('already exists')) {
      return res.status(400).json({ message: err.message });
    }
    res.status(500).json({ message: 'Server error', error: err.message });
  } finally {
    connection.release();
  }
}

async function updateMember(req, res) {
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();

    const { id } = req.params;
    const idNum = parseInt(id, 10);
    const isNum = !isNaN(idNum);

    const { name, phone, email, gender, height, weight, bmi,
      plan, duration, joinDate, expiryDate, status,
      photo, notes, address, username,
      dob, age, employer, occupation,
      emergency_contact_name, emergency_contact_relationship, emergency_contact_address,
      emergency_contact_phone_home, emergency_contact_phone_work,
      fitness_goal, blood_group, pt_form_completed,
      fingerprintId } = req.body;
    // ensure numeric values are correctly typed
    const numHeight = height != null && !isNaN(height) ? Number(height) : null;
    const numWeight = weight != null && !isNaN(weight) ? Number(weight) : null;
    const numBmi = bmi != null && !isNaN(bmi) ? Number(bmi) : null;
    const numDuration = duration != null && !isNaN(duration) ? Number(duration) : null;

    // Check for duplicate phone if phone is being updated
    if (phone) {
      let dupQuery;
      let dupParams;
      if (isNum) {
        dupQuery = `SELECT * FROM gym_members WHERE phone = ? AND id != ?`;
        dupParams = [phone, idNum];
      } else {
        dupQuery = `SELECT * FROM gym_members WHERE phone = ? AND member_id != ?`;
        dupParams = [phone, id];
      }

      const [existing] = await connection.query(dupQuery, dupParams);
      if (existing.length > 0) {
        await connection.rollback();
        return res.status(400).json({ message: "Phone already exists" });
      }
    }

    let updateQuery;
    let updateParams;
    if (isNum) {
      updateQuery = `UPDATE gym_members SET
        name=?, phone=?, email=?, gender=?,
        height=?, weight=?, bmi=?, plan=?, duration=?,
        join_date=?, expiry_date=?, status=?,
        photo=?, notes=?, address=?,
        dob=?, age=?, employer=?, occupation=?,
        emergency_contact_name=?, emergency_contact_relationship=?, emergency_contact_address=?,
        emergency_contact_phone_home=?, emergency_contact_phone_work=?,
        fitness_goal=?, blood_group=?, pt_form_completed=?,
        fingerprint_id=?,
        updated_at=CURRENT_TIMESTAMP
       WHERE id=?`;
      updateParams = [
        name, phone, email, gender, numHeight, numWeight, numBmi,
        plan, numDuration, joinDate, expiryDate, status,
        photo, notes, address,
        dob || null, age || null, employer || null, occupation || null,
        emergency_contact_name || null, emergency_contact_relationship || null, emergency_contact_address || null,
        emergency_contact_phone_home || null, emergency_contact_phone_work || null,
        fitness_goal || null, blood_group || null,
        pt_form_completed ? 1 : 0,
        fingerprintId || null,
        idNum
      ];
    } else {
      updateQuery = `UPDATE gym_members SET
        name=?, phone=?, email=?, gender=?,
        height=?, weight=?, bmi=?, plan=?, duration=?,
        join_date=?, expiry_date=?, status=?,
        photo=?, notes=?, address=?,
        dob=?, age=?, employer=?, occupation=?,
        emergency_contact_name=?, emergency_contact_relationship=?, emergency_contact_address=?,
        emergency_contact_phone_home=?, emergency_contact_phone_work=?,
        fitness_goal=?, blood_group=?, pt_form_completed=?,
        fingerprint_id=?,
        updated_at=CURRENT_TIMESTAMP
       WHERE member_id=?`;
      updateParams = [
        name, phone, email, gender, numHeight, numWeight, numBmi,
        plan, numDuration, joinDate, expiryDate, status,
        photo, notes, address,
        dob || null, age || null, employer || null, occupation || null,
        emergency_contact_name || null, emergency_contact_relationship || null, emergency_contact_address || null,
        emergency_contact_phone_home || null, emergency_contact_phone_work || null,
        fitness_goal || null, blood_group || null,
        pt_form_completed ? 1 : 0,
        fingerprintId || null,
        id
      ];
    }

    const [result] = await connection.query(updateQuery, updateParams);

    if (result.affectedRows === 0) {
      await connection.rollback();
      return res.status(404).json({ error: 'Member not found' });
    }

    // Fetch the updated member to get user ID and sync memberships table
    let sql;
    let params;
    if (isNum) {
      sql = `
        SELECT gm.*,
               u.id AS u_id,
               u.user_id AS u_uuid,
               u.email AS user_email,
               (SELECT COUNT(*) FROM workout_programs wp WHERE wp.member_id = gm.id) AS workout_count,
               (SELECT COUNT(*) FROM diet_plans dp WHERE dp.member_id = gm.id) AS diet_count
        FROM gym_members gm
        LEFT JOIN users u ON (u.email = gm.email AND gm.email IS NOT NULL AND gm.email != '') OR (u.mobile = gm.phone AND gm.phone IS NOT NULL AND gm.phone != '')
        WHERE gm.id = ?
      `;
      params = [idNum];
    } else {
      sql = `
        SELECT gm.*,
               u.id AS u_id,
               u.user_id AS u_uuid,
               u.email AS user_email,
               (SELECT COUNT(*) FROM workout_programs wp WHERE wp.member_id = gm.id) AS workout_count,
               (SELECT COUNT(*) FROM diet_plans dp WHERE dp.member_id = gm.id) AS diet_count
        FROM gym_members gm
        LEFT JOIN users u ON (u.email = gm.email AND gm.email IS NOT NULL AND gm.email != '') OR (u.mobile = gm.phone AND gm.phone IS NOT NULL AND gm.phone != '')
        WHERE gm.member_id = ?
      `;
      params = [id];
    }

    const [rows] = await connection.query(sql, params);
    const updatedMember = rows[0];

    // SYNC with memberships table (history/tracking)
    if (updatedMember && updatedMember.u_id) {
      try {
        await connection.query(
          `UPDATE memberships 
           SET endDate = ?, 
               startDate = ?, 
               duration = ?, 
               planName = ?,
               userName = ?,
               userEmail = ?,
               userPhone = ?
           WHERE userId = ? 
           ORDER BY createdAt DESC 
           LIMIT 1`,
          [
            expiryDate || updatedMember.expiry_date,
            joinDate || updatedMember.join_date,
            numDuration || updatedMember.duration,
            plan || updatedMember.plan,
            name || updatedMember.name,
            email || updatedMember.email,
            phone || updatedMember.phone,
            updatedMember.u_id
          ]
        );
      } catch (syncErr) {
        console.warn('updateMember: failed to sync memberships table', syncErr.message);
      }
    }

    // sync user info (email / mobile / username)
    try {
      const userFields = [];
      const userParams = [];
      if (email !== undefined) {
        userFields.push('email = ?');
        userParams.push(email);
      }
      if (phone !== undefined) {
        userFields.push('mobile = ?');
        userParams.push(phone);
      }
      if (username !== undefined) {
        userFields.push('username = ?');
        userParams.push(username);
      }
      if (userFields.length > 0) {
        const whereClause = [];
        const whereParams = [];
        // identify user by old email or mobile
        if (email) {
          whereClause.push('email = ?');
          whereParams.push(email);
        }
        if (phone) {
          whereClause.push('mobile = ?');
          whereParams.push(phone);
        }
        if (whereClause.length) {
          const updateSql = `UPDATE users SET ${userFields.join(', ')} WHERE ${whereClause.join(' OR ')}`;
          await connection.query(updateSql, [...userParams, ...whereParams]);
        }
      }
    } catch (userErr) {
      console.warn('updateMember: failed to sync user', userErr.message);
      // continue without fatal error
    }

    await connection.commit();
    res.json(updatedMember);

  } catch (err) {
    await connection.rollback();
    console.error('updateMember error', err);
    res.status(500).json({ message: "Server error" });
  } finally {
    connection.release();
  }
}

async function deleteMember(req, res) {
  try {
    const { id } = req.params;
    const idNum = parseInt(id, 10);
    const isNum = !isNaN(idNum);

    let deleteQuery;
    let deleteParams;
    if (isNum) {
      deleteQuery = `DELETE FROM gym_members WHERE id = ?`;
      deleteParams = [idNum];
    } else {
      deleteQuery = `DELETE FROM gym_members WHERE member_id = ?`;
      deleteParams = [id];
    }

    const [result] = await db.query(deleteQuery, deleteParams);

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Member not found' });
    }

    res.json({ success: true, message: 'Member deleted successfully' });
  } catch (err) {
    console.error('deleteMember error', err);
    res.status(500).json({ error: 'Delete failed' });
  }
}

async function getMemberPlans(req, res) {
  try {
    const { id } = req.params;
    const userId = parseInt(id, 10);

    if (isNaN(userId)) {
      return res.status(400).json({ error: 'Invalid user ID' });
    }

    // Get member info and their plan
    const sql = `
      SELECT m.membership_plan_id, p.*, m.is_active as member_active
      FROM members m
      LEFT JOIN plans p ON m.membership_plan_id = p.id
      WHERE m.user_id = ?
    `;

    const [rows] = await db.query(sql, [userId]);

    if (rows.length === 0) {
      return res.json([]); // No member found, return empty array
    }

    const member = rows[0];

    if (!member.membership_plan_id) {
      return res.json([]); // No plan assigned
    }

    // Return plan with status
    const planWithStatus = {
      ...member,
      status: member.member_active ? 'active' : 'inactive'
    };

    // Remove redundant fields
    delete planWithStatus.membership_plan_id;
    delete planWithStatus.member_active;

    res.json([planWithStatus]);
  } catch (err) {
    console.error('getMemberPlans error', err);
    res.status(500).json({ error: 'Query failed' });
  }
}

async function deleteAllMembers(req, res) {
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();
    await connection.query('DELETE FROM gym_members');
    await connection.query("DELETE FROM users WHERE role = 'user'");
    await connection.commit();
    res.json({ message: 'All members and user accounts deleted successfully' });
  } catch (err) {
    await connection.rollback();
    console.error('deleteAllMembers error', err);
    res.status(500).json({ error: 'Failed to delete all members' });
  } finally {
    connection.release();
  }
}

module.exports = {
  getAllMembers,
  getMemberById,
  getMemberByUserId,
  createMember,
  createMemberRecord,
  updateMember,
  deleteMember,
  getMemberPlans,
  deleteAllMembers
};
