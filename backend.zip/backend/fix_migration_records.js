/**
 * This script updates the schema_migrations table to reflect the renamed migration files.
 * This is needed because the migration files were renamed to fix duplicate numbering,
 * but the old filenames are still recorded in the database.
 * 
 * Run this AFTER the database is connected and before running migrations again.
 */

require('dotenv').config();
const pool = require('./src/config/db');

const MIGRATION_RENAMES = [
  { old: '0023_update_gym_plans_table.sql', new: '0023b_update_gym_plans_table.sql' },
  { old: '0024_create_enquiries_table.sql', new: '0024b_create_enquiries_table.sql' },
  { old: '0042_add_pt_form_completed_to_members.sql', new: '0042b_add_pt_form_completed_to_members.sql' },
  { old: '0046_add_second_payment_to_memberships_table.sql', new: '0046b_add_second_payment_to_memberships_table.sql' }
];

async function fixMigrationRecords() {
  try {
    console.log('Checking schema_migrations table...\n');
    
    for (const rename of MIGRATION_RENAMES) {
      const [rows] = await pool.query(
        'SELECT COUNT(*) as cnt FROM schema_migrations WHERE filename = ?',
        [rename.old]
      );
      
      if (rows[0].cnt > 0) {
        console.log(`✓ Found: ${rename.old}`);
        await pool.query(
          'UPDATE schema_migrations SET filename = ? WHERE filename = ?',
          [rename.new, rename.old]
        );
        console.log(`  → Renamed to: ${rename.new}\n`);
      } else {
        console.log(`✗ Not found: ${rename.old} (may already be updated)\n`);
      }
    }
    
    console.log('✅ Migration record fix complete!');
    process.exit(0);
  } catch(err) {
    console.error('❌ Error fixing migration records:', err.message);
    process.exit(1);
  }
}

fixMigrationRecords();
